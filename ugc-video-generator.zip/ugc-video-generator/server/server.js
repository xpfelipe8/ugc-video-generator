'use strict';
/**
 * server.js — Servidor Express principal (porta 5000 por padrão).
 */
const express = require('express');
const helmet = require('helmet');
const config = require('./config');
const logger = require('./logger');
require('./database'); // inicializa o SQLite
const ffmpegService = require('./services/ffmpegService');
const worker = require('./workers/videoWorker');

const app = express();
app.disable('x-powered-by');

// Segurança básica: cabeçalhos HTTP (CSP sem upgrade-insecure-requests para funcionar em http://localhost)
app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: true,
    directives: { 'upgrade-insecure-requests': null, 'media-src': ["'self'", 'blob:'] },
  },
}));
app.use(express.json({ limit: '100kb' }));

// Log de requisições da API
app.use('/api', (req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    if (!req.originalUrl.startsWith('/api/status')) logger.info(`${req.method} ${req.originalUrl} → ${res.statusCode} (${Date.now() - start}ms)`);
  });
  next();
});

app.get('/api/health', (req, res) => res.json({ ok: true, uptime: process.uptime() }));
app.use('/api/videos', require('./routes/videos'));
app.use('/api/templates', require('./routes/templates'));
app.use('/api/status', require('./routes/status'));
app.use('/api', (req, res) => res.status(404).json({ error: 'Rota não encontrada.' }));

// Frontend estático
app.use(express.static(config.PUBLIC_DIR));

// Tratamento de erros (JSON inválido, etc.)
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'JSON inválido.' });
  if (err.type === 'entity.too.large') return res.status(413).json({ error: 'Requisição grande demais.' });
  logger.error(err);
  res.status(err.status || 500).json({ error: err.status ? err.message : 'Erro interno do servidor.' });
});

const server = app.listen(config.PORT, async () => {
  logger.info(`Servidor rodando em http://localhost:${config.PORT}`);
  const ok = await ffmpegService.checkFfmpeg();
  if (!ok) logger.warn('Servidor ativo, mas renderizações vão falhar até o FFmpeg ser instalado.');
  logger.info(`IA: Claude ${config.ANTHROPIC_API_KEY ? 'ativo' : 'sem chave'} | OpenAI ${config.OPENAI_API_KEY ? 'ativo' : 'sem chave'}`);
  worker.start();
});

server.on('error', (err) => {
  logger.error(err.code === 'EADDRINUSE' ? `Porta ${config.PORT} já está em uso. Altere PORT no .env.` : err);
  process.exit(1);
});

function shutdown(signal) {
  logger.info(`${signal} recebido, encerrando...`);
  worker.stop();
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 3000).unref();
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
