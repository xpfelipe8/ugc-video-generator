'use strict';
/**
 * config.js — Configurações globais do projeto.
 * Valores vêm do arquivo .env (veja .env.example) com padrões seguros.
 */
const path = require('path');
const fs = require('fs');

require('dotenv').config({ path: path.join(__dirname, '.env'), quiet: true });

const num = (v, def) => {
  const n = parseInt(v, 10);
  return Number.isFinite(n) && n > 0 ? n : def;
};

const DATA_DIR = path.resolve(__dirname, process.env.DATA_DIR || 'data');

// Fontes comuns em Linux/macOS — a primeira que existir é usada no texto dos vídeos
const FONT_CANDIDATES = [
  process.env.FONT_FILE,
  '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
  '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf',
  '/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf',
  '/usr/share/fonts/TTF/DejaVuSans-Bold.ttf',
  '/System/Library/Fonts/Supplemental/Arial Bold.ttf',
  '/System/Library/Fonts/Helvetica.ttc',
].filter(Boolean);

const config = {
  PORT: num(process.env.PORT, 5000),
  NODE_ENV: process.env.NODE_ENV || 'development',

  // Pastas de dados (criadas automaticamente)
  DATA_DIR,
  DB_PATH: path.join(DATA_DIR, 'db.sqlite'),
  OUTPUT_DIR: path.join(DATA_DIR, 'videos'),
  TMP_DIR: path.join(DATA_DIR, 'tmp'),
  PUBLIC_DIR: path.resolve(__dirname, '..', 'public'),

  // FFmpeg
  FFMPEG_PATH: process.env.FFMPEG_PATH || 'ffmpeg',
  FFPROBE_PATH: process.env.FFPROBE_PATH || 'ffprobe',
  FONT_FILE: FONT_CANDIDATES.find((f) => fs.existsSync(f)) || null,
  FPS: num(process.env.VIDEO_FPS, 30),
  X264_PRESET: process.env.X264_PRESET || 'veryfast',
  X264_CRF: num(process.env.X264_CRF, 18),
  RENDER_TIMEOUT_MS: num(process.env.RENDER_TIMEOUT_MS, 30 * 60 * 1000),

  // Fila / worker
  MAX_CONCURRENT_JOBS: num(process.env.MAX_CONCURRENT_JOBS, 2),
  WORKER_POLL_MS: 1000,

  // IA (opcional — sem chaves o sistema usa fallback local)
  ANTHROPIC_API_KEY: process.env.ANTHROPIC_API_KEY || '',
  ANTHROPIC_MODEL: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5',
  OPENAI_API_KEY: process.env.OPENAI_API_KEY || '',
  OPENAI_CHAT_MODEL: process.env.OPENAI_CHAT_MODEL || 'gpt-4o-mini',
  OPENAI_TTS_MODEL: process.env.OPENAI_TTS_MODEL || 'tts-1',
  OPENAI_TTS_VOICE: process.env.OPENAI_TTS_VOICE || 'alloy',

  // Limites de validação
  MAX_SCRIPT_CHARS: 5000,
  MIN_SCRIPT_CHARS: 10,
  MAX_TITLE_CHARS: 120,
  MAX_SCENES: 12,

  // Qualidades: lado menor / lado maior do vídeo (em pixels)
  QUALITIES: {
    '720p': { short: 720, long: 1280 },
    '1080p': { short: 1080, long: 1920 },
    '2k': { short: 1440, long: 2560 },
    '4k': { short: 2160, long: 3840 },
  },
  ASPECTS: ['9:16', '16:9', '1:1'],
};

for (const dir of [config.DATA_DIR, config.OUTPUT_DIR, config.TMP_DIR]) {
  fs.mkdirSync(dir, { recursive: true });
}

/** Retorna {width, height} (sempre pares) para qualidade + proporção. */
config.getResolution = (quality, aspect) => {
  const q = config.QUALITIES[quality];
  if (!q) throw new Error(`Qualidade inválida: ${quality}`);
  if (aspect === '16:9') return { width: q.long, height: q.short };
  if (aspect === '1:1') return { width: q.short, height: q.short };
  return { width: q.short, height: q.long }; // 9:16 (padrão UGC / TikTok / Reels)
};

module.exports = config;
