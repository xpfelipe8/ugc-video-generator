// api.js — Cliente da API REST
// Se o servidor responder 401 (sessão expirada / não logado), manda para a tela de login.
function handleUnauthorized(res, path) {
  if (res.status === 401 && !path.startsWith('/api/auth/')) {
    location.href = '/login.html';
    throw new Error('Sessão expirada. Faça login novamente.');
  }
}

async function request(path, options = {}) {
  const res = await fetch(path, {
    headers: options.body ? { 'Content-Type': 'application/json' } : undefined,
    ...options,
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  handleUnauthorized(res, path);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Erro ${res.status}`);
  return data;
}

/** Upload "cru": o corpo da requisição é o próprio arquivo. */
async function uploadFile(path, file) {
  const res = await fetch(path, {
    method: 'POST',
    headers: { 'Content-Type': file.type || 'application/octet-stream', 'X-Filename': encodeURIComponent(file.name) },
    body: file,
  });
  handleUnauthorized(res, path);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Erro ${res.status}`);
  return data;
}

const api = {
  // Autenticação
  me: () => request('/api/auth/me'),
  login: (user, password) => request('/api/auth/login', { method: 'POST', body: { user, password } }),
  logout: () => request('/api/auth/logout', { method: 'POST' }),

  // Vídeos
  templates: () => request('/api/templates'),
  listVideos: (params = {}) => request(`/api/videos/list?${new URLSearchParams(params)}`),
  createVideo: (payload) => request('/api/videos/create', { method: 'POST', body: payload }),
  getVideo: (id) => request(`/api/videos/${id}`),
  deleteVideo: (id) => request(`/api/videos/${id}`, { method: 'DELETE' }),
  jobStatus: (jobId) => request(`/api/status/${jobId}`),

  // Biblioteca de mídias (imagens, clipes e músicas)
  listAssets: (kind) => request(`/api/assets${kind ? `?kind=${kind}` : ''}`),
  uploadAsset: (file) => uploadFile('/api/assets/upload', file),
  deleteAsset: (id) => request(`/api/assets/${id}`, { method: 'DELETE' }),
};
