// main.js — Lógica do frontend (usada por index.html e dashboard.html)
// Cada página só ativa os blocos cujos elementos existem.

const POLL_MS = 1500;
const polling = new Map(); // jobId -> timer

// Estado do formulário de criação
const state = {
  library: [],       // mídias enviadas (imagens, clipes e músicas)
  selected: [],      // ids de imagens/clipes escolhidos, na ordem de uso
  maxAssets: 12,
  musicPresets: {},  // nome -> rótulo
};

const MUSIC_LABELS = { calm: 'Calma', upbeat: 'Animada' };
const CAPTION_LABELS = { block: 'Bloco (frase inteira)', words: 'Palavra por palavra (estilo TikTok)' };

// ---------- Sessão (login) ----------
async function initAuth() {
  const me = await api.me();
  if (me.authEnabled && !me.authenticated) { location.href = '/login.html'; return false; }
  const box = $('#authBox');
  if (box && me.authEnabled) {
    box.innerHTML = `<button class="ghost sm" id="logoutBtn" title="Sair (${esc(me.user)})">Sair</button>`;
    $('#logoutBtn').addEventListener('click', async () => {
      await api.logout().catch(() => {});
      location.href = '/login.html';
    });
  }
  return true;
}

// ---------- Cartão de vídeo (galeria) ----------
function videoCard(v) {
  const active = v.status === 'queued' || v.status === 'processing';
  const thumb = v.status === 'completed'
    ? `<video src="${esc(v.streamUrl)}" controls preload="metadata" playsinline></video>`
    : active ? `<div>${esc(STATUS_LABEL[v.status])}…<br>${v.progress ?? 0}%</div>`
    : `<div class="err">${esc(v.error || 'Erro ao gerar')}</div>`;
  return `
    <article class="vcard" data-id="${esc(v.id)}">
      <div class="vthumb">${thumb}</div>
      <div class="vbody">
        <div class="vtitle" title="${esc(v.title)}">${esc(v.title)}</div>
        <div><span class="badge ${esc(v.status)}">${esc(STATUS_LABEL[v.status])}</span></div>
        <div class="vmeta">${esc(v.template)} · ${esc(v.quality)} · ${esc(v.aspect)}${v.durationSec ? ' · ' + formatDuration(v.durationSec) : ''}</div>
        <div class="vactions">
          ${v.downloadUrl ? `<a class="btn sm" href="${esc(v.downloadUrl)}">Baixar</a>` : ''}
          <button class="ghost danger sm" data-delete="${esc(v.id)}" ${v.status === 'processing' ? 'disabled' : ''}>Excluir</button>
        </div>
      </div>
    </article>`;
}

// ---------- Progresso em tempo real ----------
function renderActiveJob(job, title) {
  const box = $('#activeJobs');
  if (!box) return;
  const hint = $('#noJobs');
  if (hint) hint.remove(); // some o aviso quando há um job ativo
  let el = box.querySelector(`[data-job="${job.jobId}"]`);
  if (!el) {
    el = document.createElement('div');
    el.className = 'active-job';
    el.dataset.job = job.jobId;
    box.prepend(el);
  }
  el.innerHTML = `
    <div class="top"><strong>${esc(title)}</strong><span>${esc(job.stage)} · ${job.progress}%</span></div>
    <div class="bar"><i style="width:${job.progress}%"></i></div>
    ${job.error ? `<div class="err">${esc(job.error)}</div>` : ''}`;
  return el;
}

function trackJob(jobId, title, onDone) {
  if (polling.has(jobId)) return;
  const tick = async () => {
    try {
      const job = await api.jobStatus(jobId);
      const el = renderActiveJob(job, title);
      if (job.status === 'completed' || job.status === 'failed') {
        polling.delete(jobId);
        toast(job.status === 'completed' ? `“${title}” está pronto!` : `Falha em “${title}”`, job.status === 'failed');
        setTimeout(() => el && el.remove(), 2500);
        onDone && onDone();
        return;
      }
    } catch (err) {
      polling.delete(jobId);
      return;
    }
    polling.set(jobId, setTimeout(tick, POLL_MS));
  };
  polling.set(jobId, setTimeout(tick, 200));
}

// ---------- Galeria (index.html) ----------
async function refreshGallery() {
  const gallery = $('#gallery');
  if (!gallery) return;
  try {
    const { videos } = await api.listVideos({ limit: 24 });
    gallery.innerHTML = videos.length ? videos.map(videoCard).join('') : '<div class="empty">Nenhum vídeo ainda. Crie o primeiro ao lado!</div>';
    // Retoma o acompanhamento de jobs ativos (ex.: após recarregar a página)
    videos.filter((v) => v.jobId && (v.status === 'queued' || v.status === 'processing'))
      .forEach((v) => trackJob(v.jobId, v.title, refreshGallery));
  } catch (err) { toast(err.message, true); }
}

// ---------- Biblioteca de mídias ----------
function mediaItem(a) {
  const idx = state.selected.indexOf(a.id);
  const thumb = a.kind === 'image'
    ? `<img src="${esc(a.url)}" alt="${esc(a.name)}" loading="lazy">`
    : `<video src="${esc(a.url)}#t=0.5" muted preload="metadata"></video>`;
  return `
    <div class="media-item ${idx >= 0 ? 'selected' : ''}" data-asset="${esc(a.id)}" title="${esc(a.name)}">
      ${thumb}
      ${a.kind === 'video' ? '<span class="kind">clipe</span>' : ''}
      ${idx >= 0 ? `<b class="order">${idx + 1}</b>` : ''}
      <button type="button" class="x" data-del-asset="${esc(a.id)}" title="Excluir da biblioteca" aria-label="Excluir ${esc(a.name)}">×</button>
    </div>`;
}

function renderLibrary() {
  const grid = $('#mediaLibrary');
  if (!grid) return;
  const items = state.library.filter((a) => a.kind !== 'audio');
  grid.innerHTML = items.length ? items.map(mediaItem).join('') : '<div class="hint">Nenhuma mídia ainda — envie fotos ou clipes do produto.</div>';
}

function renderMusicOptions(keep) {
  const select = $('#music');
  if (!select) return;
  const current = keep ?? select.value;
  const options = [['', 'Sem música']];
  for (const name of Object.keys(state.musicPresets)) options.push([`preset:${name}`, `${state.musicPresets[name]} (trilha sintética)`]);
  for (const a of state.library.filter((x) => x.kind === 'audio')) options.push([`asset:${a.id}`, `🎵 ${a.name}`]);
  select.innerHTML = options.map(([v, label]) => `<option value="${esc(v)}">${esc(label)}</option>`).join('');
  select.value = options.some(([v]) => v === current) ? current : '';
  updateVolumeState();
}

function updateVolumeState() {
  const off = !$('#music').value;
  $('#musicVolume').disabled = off;
  $('.volume').classList.toggle('off', off);
}

async function loadLibrary() {
  const { assets } = await api.listAssets();
  state.library = assets;
  state.selected = state.selected.filter((id) => assets.some((a) => a.id === id)); // remove ids que não existem mais
  renderLibrary();
  renderMusicOptions();
}

/** Envia arquivos um a um; imagens/clipes novos já ficam selecionados. */
async function uploadFiles(files, { forMusic = false } = {}) {
  const status = $('#uploadStatus');
  const list = Array.from(files);
  let sent = 0;
  let lastAudioId = null;
  for (const file of list) {
    status.textContent = `Enviando ${sent + 1}/${list.length}: ${file.name}…`;
    try {
      const { asset } = await api.uploadAsset(file);
      state.library.unshift(asset);
      if (asset.kind === 'audio') lastAudioId = asset.id;
      else if (state.selected.length < state.maxAssets) state.selected.push(asset.id);
    } catch (err) { toast(`${file.name}: ${err.message}`, true); }
    sent++;
  }
  status.textContent = '';
  renderLibrary();
  renderMusicOptions(lastAudioId && forMusic ? `asset:${lastAudioId}` : undefined);
}

function initMedia() {
  const grid = $('#mediaLibrary');
  const zone = $('#mediaZone');

  grid.addEventListener('click', async (e) => {
    const del = e.target.closest('[data-del-asset]');
    if (del) {
      e.stopPropagation();
      if (!confirm('Excluir esta mídia da biblioteca?')) return;
      try { await api.deleteAsset(del.dataset.delAsset); await loadLibrary(); toast('Mídia excluída.'); }
      catch (err) { toast(err.message, true); }
      return;
    }
    const item = e.target.closest('[data-asset]');
    if (!item) return;
    const id = item.dataset.asset;
    const i = state.selected.indexOf(id);
    if (i >= 0) state.selected.splice(i, 1);
    else if (state.selected.length >= state.maxAssets) return toast(`Máximo de ${state.maxAssets} mídias por vídeo.`, true);
    else state.selected.push(id);
    renderLibrary();
  });

  $('#mediaInput').addEventListener('change', (e) => { uploadFiles(e.target.files); e.target.value = ''; });
  $('#musicInput').addEventListener('change', (e) => { uploadFiles(e.target.files, { forMusic: true }); e.target.value = ''; });

  // Arrastar e soltar
  zone.addEventListener('dragover', (e) => { e.preventDefault(); zone.classList.add('dragover'); });
  zone.addEventListener('dragleave', () => zone.classList.remove('dragover'));
  zone.addEventListener('drop', (e) => {
    e.preventDefault();
    zone.classList.remove('dragover');
    if (e.dataTransfer.files.length) uploadFiles(e.dataTransfer.files);
  });

  $('#music').addEventListener('change', updateVolumeState);
  $('#musicVolume').addEventListener('input', (e) => { $('#musicVolumeLabel').textContent = e.target.value; });
}

// ---------- Formulário de criação ----------
async function initCreateForm() {
  const form = $('#createForm');
  if (!form) return;

  const { templates, options } = await api.templates();
  state.maxAssets = options.maxAssets;
  state.musicPresets = Object.fromEntries(options.musicPresets.map((n) => [n, MUSIC_LABELS[n] || n]));

  $('#template').innerHTML = templates.map((t) => `<option value="${esc(t.id)}">${esc(t.name)} — ${esc(t.description)}</option>`).join('');
  $('#quality').innerHTML = options.qualities.map((q) => `<option ${q === '1080p' ? 'selected' : ''}>${esc(q)}</option>`).join('');
  $('#aspect').innerHTML = options.aspects.map((a) => `<option>${esc(a)}</option>`).join('');
  $('#captionStyle').innerHTML = options.captionStyles.map((c) => `<option value="${esc(c)}">${esc(CAPTION_LABELS[c] || c)}</option>`).join('');
  $('#musicVolume').value = options.defaultMusicVolume;
  $('#musicVolumeLabel').textContent = options.defaultMusicVolume;
  $('#aiHint').textContent = options.ai.claude || options.ai.openai
    ? `IA ativa: ${[options.ai.claude && 'Claude', options.ai.openai && 'OpenAI'].filter(Boolean).join(' + ')}`
    : 'Sem chaves de IA no .env — o roteiro será dividido localmente.';
  $('#voiceHint').textContent = options.ai.openai ? 'Usa OpenAI TTS. A música abaixa sozinha enquanto a voz fala.' : 'Requer OPENAI_API_KEY no .env.';

  initMedia();
  await loadLibrary();

  const script = $('#script');
  const counter = $('#counter');
  script.maxLength = options.maxScriptChars;
  script.addEventListener('input', () => { counter.textContent = `${script.value.length}/${options.maxScriptChars}`; });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = $('#submitBtn');
    btn.disabled = true;
    try {
      const { video, job } = await api.createVideo({
        title: $('#title').value, script: script.value,
        template: $('#template').value, quality: $('#quality').value, aspect: $('#aspect').value,
        useAI: $('#useAI').checked, useVoice: $('#useVoice').checked,
        assets: state.selected, captionStyle: $('#captionStyle').value,
        music: $('#music').value, musicVolume: parseInt($('#musicVolume').value, 10),
      });
      toast('Vídeo na fila!');
      renderActiveJob(job, video.title);
      trackJob(job.jobId, video.title, refreshGallery);
      refreshGallery();
    } catch (err) { toast(err.message, true); }
    finally { btn.disabled = false; }
  });
}

// ---------- Dashboard (dashboard.html) ----------
async function refreshDashboard() {
  const table = $('#historyBody');
  if (!table) return;
  try {
    const { videos, stats } = await api.listVideos({ limit: 100 });
    $('#sTotal').textContent = stats.total;
    $('#sDone').textContent = stats.completed;
    $('#sActive').textContent = stats.active;
    $('#sFailed').textContent = stats.failed;
    $('#sDuration').textContent = formatDuration(stats.seconds);
    $('#sSize').textContent = formatBytes(stats.bytes);
    table.innerHTML = videos.length ? videos.map((v) => `
      <tr>
        <td>${esc(v.title)}</td>
        <td>${esc(v.template)}</td>
        <td>${esc(v.quality)} · ${esc(v.aspect)}</td>
        <td><span class="badge ${esc(v.status)}">${esc(STATUS_LABEL[v.status])}</span>${v.status === 'processing' ? ` ${v.progress}%` : ''}${v.status === 'failed' ? `<div class="err">${esc(v.error)}</div>` : ''}</td>
        <td>${formatDuration(v.durationSec)}</td>
        <td>${formatBytes(v.fileSize)}</td>
        <td>${formatDate(v.createdAt)}</td>
        <td>${v.downloadUrl ? `<a class="btn sm" href="${esc(v.downloadUrl)}">Baixar</a> ` : ''}<button class="ghost danger sm" data-delete="${esc(v.id)}" ${v.status === 'processing' ? 'disabled' : ''}>Excluir</button></td>
      </tr>`).join('') : '<tr><td colspan="8" class="empty">Nenhum vídeo gerado ainda.</td></tr>';
    if (stats.active) setTimeout(refreshDashboard, 3000); // atualiza enquanto houver jobs ativos
  } catch (err) { toast(err.message, true); }
}

// ---------- Excluir vídeo (delegação de eventos) ----------
document.addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-delete]');
  if (!btn) return;
  if (!confirm('Excluir este vídeo definitivamente?')) return;
  try {
    await api.deleteVideo(btn.dataset.delete);
    toast('Vídeo excluído.');
    refreshGallery();
    refreshDashboard();
  } catch (err) { toast(err.message, true); }
});

document.addEventListener('DOMContentLoaded', async () => {
  try {
    if (!(await initAuth())) return;
  } catch (err) { toast(err.message, true); return; }
  initCreateForm().catch((err) => toast(err.message, true));
  refreshGallery();
  refreshDashboard();
});
