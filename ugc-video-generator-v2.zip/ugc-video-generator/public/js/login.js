// login.js — Tela de login
document.addEventListener('DOMContentLoaded', async () => {
  // Já logado (ou autenticação desligada)? Vai direto para o painel.
  try {
    const me = await api.me();
    if (!me.authEnabled || me.authenticated) { location.href = '/'; return; }
  } catch (_) { /* mostra o formulário mesmo assim */ }

  $('#loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = $('#loginBtn');
    const errorBox = $('#loginError');
    errorBox.textContent = '';
    btn.disabled = true;
    try {
      await api.login($('#user').value.trim(), $('#password').value);
      location.href = '/';
    } catch (err) {
      errorBox.textContent = err.message;
      $('#password').select();
    } finally { btn.disabled = false; }
  });
});
