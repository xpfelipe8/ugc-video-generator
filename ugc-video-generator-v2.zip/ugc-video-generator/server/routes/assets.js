'use strict';
/** routes/assets.js — Rotas /api/assets (biblioteca de mídias) */
const express = require('express');
const rateLimit = require('express-rate-limit');
const controller = require('../controllers/assetController');

const router = express.Router();

const uploadLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 60,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Muitos uploads. Aguarde um minuto.' },
});

router.post('/upload', uploadLimiter, controller.upload);
router.get('/', controller.list);
router.get('/:id/file', controller.file);
router.delete('/:id', controller.remove);

module.exports = router;
