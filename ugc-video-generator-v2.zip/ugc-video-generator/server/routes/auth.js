'use strict';
/** routes/auth.js — Login, logout e estado da sessão (/api/auth/*) */
const express = require('express');
const rateLimit = require('express-rate-limit');
const config = require('../config');
const logger = require('../logger');
const auth = require('../middleware/auth');

const router = express.Router();

// Anti força-bruta: 10 tentativas FALHAS a cada 15 min por IP
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  skipSuccessfulRequests: true,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Muitas tentativas de login. Aguarde alguns minutos.' },
});

router.post('/login', loginLimiter, (req, res) => {
  if (!auth.enabled) return res.json({ ok: true, authEnabled: false });
  const { user = '', password = '' } = req.body || {};
  const userOk = auth.safeEqual(String(user), config.AUTH_USER);
  const passOk = Boolean(config.AUTH_PASSWORD) && auth.safeEqual(String(password), config.AUTH_PASSWORD);
  if (!(userOk && passOk)) {
    logger.warn(`Login falhou (IP ${req.ip})`);
    return res.status(401).json({ error: 'Usuário ou senha inválidos.' });
  }
  auth.setSessionCookie(res, config.AUTH_USER);
  res.json({ ok: true, authEnabled: true, user: config.AUTH_USER });
});

router.post('/logout', (req, res) => {
  auth.clearSessionCookie(res);
  res.json({ ok: true });
});

// Público: o frontend usa para decidir se mostra a tela de login
router.get('/me', (req, res) => {
  const user = auth.authenticate(req);
  res.json({ authEnabled: auth.enabled, authenticated: Boolean(user), user: user || null });
});

module.exports = router;
