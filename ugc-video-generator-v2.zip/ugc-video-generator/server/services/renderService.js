'use strict';
/**
 * renderService.js — Orquestra a geração completa de um vídeo:
 * cenas (IA) → narração (opcional) → clipes FFmpeg → concatenação → música (opcional).
 */
const fs = require('fs');
const path = require('path');
const config = require('../config');
const ai = require('./aiService');
const ffmpeg = require('./ffmpegService');
const assetService = require('./assetService');

/** Estimativa de duração sem áudio: ~2,6 palavras/seg + respiro. */
const estimateDuration = (text) => Math.max(2.5, text.split(/\s+/).length / 2.6 + 0.8);

/** Carrega as mídias do vídeo que ainda existem em disco. */
function loadVisuals(video, log) {
  let ids = [];
  try { ids = JSON.parse(video.asset_ids || '[]'); } catch (_) { /* usa vazio */ }
  const found = ids.map((id) => assetService.getAssetRow(id)).filter((a) => a && fs.existsSync(a.file_path));
  if (ids.length && found.length < ids.length) log(`${ids.length - found.length} mídia(s) não existem mais e foram ignoradas.`);
  return found;
}

/** Resolve a música escolhida ("preset:calm" | "asset:<id>") ou null. */
function resolveMusic(video, log) {
  if (!video.music) return null;
  if (video.music.startsWith('preset:')) return { type: 'preset', name: video.music.slice(7) };
  if (video.music.startsWith('asset:')) {
    const row = assetService.getAssetRow(video.music.slice(6));
    if (row && fs.existsSync(row.file_path)) return { type: 'file', path: row.file_path };
    log('A música escolhida não existe mais — vídeo ficará sem trilha.');
  }
  return null;
}

/**
 * @param {object} video  linha da tabela videos
 * @param {object} template  config do template (JSON já parseado)
 * @param {{update:(progress:number, stage:string)=>void, log:(msg:string)=>void}} ctx
 */
async function renderVideo(video, template, ctx) {
  const { width, height } = config.getResolution(video.quality, video.aspect);
  const tmpDir = fs.mkdtempSync(path.join(config.TMP_DIR, 'job-'));

  try {
    // 1) Cenas
    ctx.update(3, 'Dividindo roteiro em cenas');
    const scenes = await ai.buildScenes(video.script, template, Boolean(video.use_ai), ctx.log);
    const visuals = loadVisuals(video, ctx.log);
    const music = resolveMusic(video, ctx.log);

    // 2) Narração + duração de cada cena
    const wantVoice = Boolean(video.use_voice);
    const voiceOk = wantVoice && ai.hasTTS();
    if (wantVoice && !voiceOk) ctx.log('Narração solicitada, mas OPENAI_API_KEY não está configurada — vídeo sem voz.');

    for (let i = 0; i < scenes.length; i++) {
      ctx.update(5 + Math.round((i / scenes.length) * 10), `Preparando cena ${i + 1}/${scenes.length}`);
      const scene = scenes[i];
      scene.audioFile = null;
      if (voiceOk) {
        try {
          const file = `voice_${i}.mp3`;
          await ai.synthesizeSpeech(scene.narration, path.join(tmpDir, file));
          scene.duration = (await ffmpeg.probeDuration(path.join(tmpDir, file))) + 0.6;
          scene.audioFile = file;
        } catch (err) {
          ctx.log(`Falha na narração da cena ${i + 1} (${err.message}) — cena ficará sem voz.`);
        }
      }
      if (!scene.audioFile) scene.duration = estimateDuration(scene.narration);
    }
    const hasVoice = scenes.some((s) => s.audioFile);

    // Associa mídias às cenas em rodízio. Clipes usam um "cursor" para mostrar trechos diferentes a cada cena.
    const cursors = {};
    scenes.forEach((s, i) => {
      if (!visuals.length) return;
      const a = visuals[i % visuals.length];
      s.visual = { kind: a.kind, path: a.file_path, start: 0 };
      if (a.kind === 'video') {
        let start = cursors[a.id] || 0;
        if (start + s.duration > (a.duration_sec || 0)) start = 0;
        cursors[a.id] = start + s.duration;
        s.visual.start = start;
      }
    });

    // 3) Clipes (15% → 93%)
    const clips = [];
    for (let i = 0; i < scenes.length; i++) {
      const s = scenes[i];
      const clip = await ffmpeg.renderClip({
        dir: tmpDir, index: i, caption: s.caption, title: video.title, duration: s.duration,
        width, height, template, audioFile: s.audioFile, visual: s.visual || null,
        captionStyle: video.caption_style,
        onProgress: (f) => ctx.update(15 + Math.round(((i + f) / scenes.length) * 78), `Renderizando cena ${i + 1}/${scenes.length}`),
      });
      clips.push(clip);
    }

    // 4) Junta tudo (+ música, se escolhida)
    ctx.update(95, 'Finalizando vídeo');
    const outFile = path.join(config.OUTPUT_DIR, `${video.id}.mp4`);
    if (music) {
      const joined = path.join(tmpDir, 'sem_musica.mp4');
      await ffmpeg.concatClips(tmpDir, clips, joined);
      ctx.update(97, 'Mixando música de fundo');
      await ffmpeg.mixMusic({
        dir: tmpDir, input: joined, output: outFile, music, volume: video.music_volume,
        duration: await ffmpeg.probeDuration(joined), hasVoice,
      });
    } else {
      await ffmpeg.concatClips(tmpDir, clips, outFile);
    }

    const duration = await ffmpeg.probeDuration(outFile);
    const size = fs.statSync(outFile).size;
    ctx.log(`Vídeo pronto: ${width}x${height}, ${duration.toFixed(1)}s, ${(size / 1048576).toFixed(1)} MB.`);
    return { filePath: outFile, duration, size, width, height };
  } finally {
    fs.rm(tmpDir, { recursive: true, force: true }, () => {}); // limpa temporários
  }
}

module.exports = { renderVideo };
