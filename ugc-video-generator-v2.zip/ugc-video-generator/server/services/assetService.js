'use strict';
/**
 * assetService.js — Biblioteca de mídias (imagens, clipes e músicas enviados).
 */
const crypto = require('crypto');
const fs = require('fs');
const db = require('../database');

const toApiAsset = (a) => a && {
  id: a.id,
  kind: a.kind,
  name: a.original_name,
  mime: a.mime,
  size: a.size,
  width: a.width,
  height: a.height,
  durationSec: a.duration_sec,
  createdAt: a.created_at,
  url: `/api/assets/${a.id}/file`,
};

function createAsset({ kind, originalName, filePath, mime, size, width, height, durationSec }, id = crypto.randomUUID()) {
  db.prepare(`INSERT INTO assets (id, kind, original_name, file_path, mime, size, width, height, duration_sec)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(id, kind, originalName, filePath, mime, size, width ?? null, height ?? null, durationSec ?? null);
  return toApiAsset(getAssetRow(id));
}

const getAssetRow = (id) => db.prepare('SELECT * FROM assets WHERE id = ?').get(id);
const getAsset = (id) => toApiAsset(getAssetRow(id));

function listAssets(kind) {
  const rows = kind
    ? db.prepare('SELECT * FROM assets WHERE kind = ? ORDER BY created_at DESC, rowid DESC').all(kind)
    : db.prepare('SELECT * FROM assets ORDER BY created_at DESC, rowid DESC').all();
  return rows.map(toApiAsset);
}

/** A mídia é usada por algum vídeo que ainda está na fila ou renderizando? */
function isAssetInUse(id) {
  const row = db.prepare(`
    SELECT 1 FROM videos
    WHERE status IN ('queued', 'processing') AND (asset_ids LIKE ? OR music = ?)
    LIMIT 1`).get(`%"${id}"%`, `asset:${id}`);
  return Boolean(row);
}

function deleteAsset(id) {
  const row = getAssetRow(id);
  if (!row) return false;
  fs.rm(row.file_path, { force: true }, () => {});
  db.prepare('DELETE FROM assets WHERE id = ?').run(id);
  return true;
}

module.exports = { createAsset, getAsset, getAssetRow, listAssets, isAssetInUse, deleteAsset };
