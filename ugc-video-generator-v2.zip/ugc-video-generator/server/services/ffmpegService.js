'use strict';
/**
 * ffmpegService.js — Toda a integração com FFmpeg fica aqui.
 *
 * Fluxo de um vídeo:
 *   1. Para cada cena: fundo (gradiente, foto do produto ou clipe) + zoom/pan + texto
 *      (bloco ou palavra por palavra) + fade + áudio (narração ou silêncio).
 *   2. Concatena todos os clipes em um MP4 final.
 *   3. (Opcional) Mixa a música de fundo, abaixando o volume quando há narração.
 */
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const config = require('../config');
const logger = require('../logger');

const BASE_ARGS = ['-y', '-hide_banner', '-loglevel', 'error', '-progress', 'pipe:1', '-nostats'];

/** Executa um binário e acompanha o progresso (out_time_us do -progress). */
function run(bin, args, { cwd, onProgress, durationSec } = {}) {
  return new Promise((resolve, reject) => {
    const proc = spawn(bin, args, { cwd, stdio: ['ignore', 'pipe', 'pipe'] });
    let stderr = '';
    let buffer = '';

    const timer = setTimeout(() => {
      proc.kill('SIGKILL');
      reject(new Error('Tempo limite de renderização excedido'));
    }, config.RENDER_TIMEOUT_MS);

    proc.stdout.on('data', (chunk) => {
      buffer += chunk;
      let idx;
      while ((idx = buffer.indexOf('\n')) >= 0) {
        const line = buffer.slice(0, idx).trim();
        buffer = buffer.slice(idx + 1);
        if (onProgress && durationSec && line.startsWith('out_time_us=')) {
          const us = parseInt(line.slice(12), 10);
          if (Number.isFinite(us)) onProgress(Math.max(0, Math.min(1, us / 1e6 / durationSec)));
        }
      }
    });
    proc.stderr.on('data', (d) => { stderr = (stderr + d).slice(-4000); });
    proc.on('error', (err) => { clearTimeout(timer); reject(new Error(`Não foi possível executar ${bin}: ${err.message}`)); });
    proc.on('close', (code) => {
      clearTimeout(timer);
      if (code === 0) return resolve();
      reject(new Error(`${bin} falhou (código ${code}): ${stderr.trim().split('\n').slice(-6).join(' | ')}`));
    });
  });
}

/** Verifica se FFmpeg/FFprobe existem (chamado na inicialização). */
async function checkFfmpeg() {
  try {
    await run(config.FFMPEG_PATH, ['-hide_banner', '-loglevel', 'error', '-version']);
    await run(config.FFPROBE_PATH, ['-hide_banner', '-loglevel', 'error', '-version']);
    if (!config.FONT_FILE) logger.warn('Nenhuma fonte TTF encontrada; defina FONT_FILE no .env se o texto não aparecer.');
    return true;
  } catch (err) {
    logger.error('FFmpeg não encontrado. Instale com: sudo apt install ffmpeg (Linux) ou brew install ffmpeg (macOS).');
    return false;
  }
}

/** Lê informações de uma mídia: dimensões, duração e quais streams existem. */
function probeMedia(file) {
  return new Promise((resolve, reject) => {
    const proc = spawn(config.FFPROBE_PATH, ['-v', 'error', '-print_format', 'json', '-show_entries', 'stream=codec_type,width,height:format=duration', file]);
    let out = '';
    proc.stdout.on('data', (d) => { out += d; });
    proc.on('error', reject);
    proc.on('close', (code) => {
      if (code !== 0) return reject(new Error(`ffprobe não conseguiu ler ${path.basename(file)}`));
      try {
        const json = JSON.parse(out);
        const streams = json.streams || [];
        const video = streams.find((s) => s.codec_type === 'video');
        resolve({
          hasVideo: Boolean(video),
          hasAudio: streams.some((s) => s.codec_type === 'audio'),
          width: video ? video.width : null,
          height: video ? video.height : null,
          duration: parseFloat(json.format && json.format.duration) || 0,
        });
      } catch (err) { reject(err); }
    });
  });
}

/** Duração (segundos) de um arquivo de mídia. */
async function probeDuration(file) {
  const info = await probeMedia(file);
  if (!(info.duration > 0)) throw new Error(`ffprobe não conseguiu ler a duração de ${path.basename(file)}`);
  return info.duration;
}

/** Quebra o texto em linhas de no máximo maxChars caracteres. */
function wrapText(text, maxChars) {
  const words = String(text).replace(/[\u0000-\u001f]+/g, ' ').trim().split(/\s+/);
  const lines = [];
  let line = '';
  for (const w of words) {
    if (line && (line + ' ' + w).length > maxChars) { lines.push(line); line = w; }
    else line = line ? `${line} ${w}` : w;
  }
  if (line) lines.push(line);
  return lines.join('\n');
}

/**
 * Legenda palavra por palavra: divide o texto em grupos de `perChunk` palavras e distribui
 * o tempo da cena proporcionalmente ao tamanho de cada grupo (estimativa de fala).
 * Retorna [{ text, start, end }] com tempos em segundos dentro da cena.
 */
function wordChunks(text, duration, perChunk = 2) {
  const words = String(text).replace(/[\u0000-\u001f]+/g, ' ').trim().split(/\s+/).filter(Boolean);
  const groups = [];
  for (let i = 0; i < words.length; i += perChunk) groups.push(words.slice(i, i + perChunk).join(' '));
  const lead = 0.25;                                  // respiro após o fade-in
  const tail = Math.min(0.35, duration * 0.15);       // respiro antes do fade-out
  const available = Math.max(0.5, duration - lead - tail);
  const weights = groups.map((g) => g.length + 3);
  const total = weights.reduce((a, b) => a + b, 0);
  let t = lead;
  return groups.map((g, i) => {
    const d = (available * weights[i]) / total;
    const chunk = { text: g, start: t, end: t + d };
    t += d;
    return chunk;
  });
}

const hex = (c) => '0x' + String(c).replace('#', '');
const escFilterPath = (p) => p.replace(/\\/g, '/').replace(/:/g, '\\:').replace(/'/g, "\\'");

/** Expressões do zoompan para cada efeito (N = total de frames da cena). */
function effectExpr(effect, N) {
  const center = { x: "'iw/2-(iw/zoom/2)'", y: "'ih/2-(ih/zoom/2)'" };
  switch (effect) {
    case 'zoom_out': return { z: `'1.14-0.14*on/${N}'`, ...center };
    case 'pan_left': return { z: "'1.14'", x: `'(iw-iw/zoom)*(1-on/${N})'`, y: center.y };
    case 'pan_right': return { z: "'1.14'", x: `'(iw-iw/zoom)*on/${N}'`, y: center.y };
    case 'zoom_in':
    default: return { z: `'1+0.14*on/${N}'`, ...center };
  }
}

const DARKEN = 'drawbox=x=0:y=0:w=iw:h=ih:color=black@0.28:t=fill'; // escurece a mídia para o texto ficar legível

/**
 * Renderiza UMA cena em clip MP4 (com áudio).
 * @param {object} o
 *   dir          pasta temporária do job (cwd do ffmpeg)
 *   index        número da cena
 *   caption      texto na tela
 *   title        título pequeno no topo
 *   duration     duração em segundos
 *   width,height
 *   template     config do template
 *   audioFile    nome do arquivo de áudio dentro de dir (ou null = silêncio)
 *   visual       null | { kind:'image'|'video', path, start? } — mídia de fundo
 *   captionStyle 'block' | 'words'
 *   onProgress   fração 0..1
 */
async function renderClip(o) {
  const { dir, index, caption, title, duration, width: W, height: H, template, audioFile, visual, onProgress } = o;
  const captionStyle = o.captionStyle === 'words' ? 'words' : 'block';
  const FPS = config.FPS;
  const N = Math.max(1, Math.round(duration * FPS));
  const baseFs = Math.round(Math.min(W, H) * 0.058);    // tamanho da fonte do bloco
  const maxChars = Math.max(10, Math.floor((W * 0.82) / (baseFs * 0.58)));
  const font = config.FONT_FILE ? `fontfile='${escFilterPath(config.FONT_FILE)}':` : '';
  const fade = 0.35;

  fs.writeFileSync(path.join(dir, `title_${index}.txt`), String(title).slice(0, 48).toUpperCase(), 'utf8');

  // ---------- 1) Fundo ----------
  let inputArgs;
  let videoChain;

  if (visual && visual.kind === 'video') {
    // Clipe do produto: preenche o quadro (corta o excesso), repete se for curto
    inputArgs = ['-stream_loop', '-1', ...(visual.start > 0 ? ['-ss', visual.start.toFixed(3)] : []), '-i', visual.path];
    videoChain = `[0:v]scale=${W}:${H}:force_original_aspect_ratio=increase,crop=${W}:${H},setsar=1,fps=${FPS},${DARKEN}`;
  } else {
    // Imagem ou gradiente: vira um PNG (com o dobro da resolução em ≤1080p para o zoom ficar suave)
    const k = Math.max(W, H) <= 1920 ? 2 : 1;
    const BW = W * k;
    const BH = H * k;
    const bg = `bg_${index}.png`;
    if (visual) {
      await run(config.FFMPEG_PATH, [
        ...BASE_ARGS, '-i', visual.path,
        '-vf', `scale=${BW}:${BH}:force_original_aspect_ratio=increase,crop=${BW}:${BH},setsar=1,${DARKEN}`,
        '-frames:v', '1', bg,
      ], { cwd: dir });
    } else {
      const corners = [[0, 0, BW, BH], [BW, 0, 0, BH], [0, BH, BW, 0], [BW, BH, 0, 0]][index % 4]; // direção varia por cena
      const [c0, c1] = template.colors;
      await run(config.FFMPEG_PATH, [
        ...BASE_ARGS, '-f', 'lavfi',
        '-i', `gradients=s=${BW}x${BH}:c0=${hex(c0)}:c1=${hex(c1)}:x0=${corners[0]}:y0=${corners[1]}:x1=${corners[2]}:y1=${corners[3]}:d=1:n=2`,
        '-frames:v', '1', bg,
      ], { cwd: dir });
    }
    const ex = effectExpr(template.effect, N);
    inputArgs = ['-i', bg];
    videoChain = `[0:v]zoompan=z=${ex.z}:x=${ex.x}:y=${ex.y}:d=${N}:s=${W}x${H}:fps=${FPS}`;
  }

  // ---------- 2) Texto ----------
  const textFilters = [
    `drawtext=${font}textfile='title_${index}.txt':expansion=none:fontsize=${Math.round(baseFs * 0.5)}:fontcolor=${hex(template.accent)}:x=(w-text_w)/2:y=h*0.07`,
  ];

  if (captionStyle === 'words') {
    // Estilo TikTok: 2 palavras por vez, grandes, com contorno, alternando branco/cor de destaque.
    // Cada grupo tem um "pop" (começa 18% maior por ~0.09s) feito com dois drawtext sequenciais.
    const y = template.textPosition === 'lower' ? 'h-text_h-h*0.22' : '(h-text_h)/2';
    wordChunks(caption, duration, 2).forEach((c, i) => {
      const file = `w_${index}_${i}.txt`;
      fs.writeFileSync(path.join(dir, file), c.text.toUpperCase(), 'utf8');
      const size = Math.max(24, Math.min(Math.round(Math.min(W, H) * 0.095), Math.floor((W * 0.8) / (c.text.length * 0.74))));
      const color = i % 2 ? hex(template.accent) : 'white';
      const draw = (sz, a, b) =>
        `drawtext=${font}textfile='${file}':expansion=none:fontsize=${sz}:fontcolor=${color}:borderw=${Math.max(4, Math.round(sz * 0.09))}:bordercolor=black:x=(w-text_w)/2:y=${y}:enable='between(t,${a.toFixed(3)},${b.toFixed(3)})'`;
      const pop = Math.min(0.09, (c.end - c.start) / 3);
      textFilters.push(draw(Math.round(size * 1.18), c.start, c.start + pop));
      textFilters.push(draw(size, c.start + pop, c.end));
    });
  } else {
    fs.writeFileSync(path.join(dir, `caption_${index}.txt`), wrapText(caption, maxChars), 'utf8');
    const yCaption = template.textPosition === 'lower' ? 'h-text_h-h*0.14' : '(h-text_h)/2';
    textFilters.push(
      `drawtext=${font}textfile='caption_${index}.txt':expansion=none:fontsize=${baseFs}:fontcolor=white:line_spacing=${Math.round(baseFs * 0.25)}:x=(w-text_w)/2:y=${yCaption}:box=1:boxcolor=black@0.38:boxborderw=${Math.round(baseFs * 0.4)}:alpha='if(lt(t,0.4),t/0.4,1)'`
    );
  }

  // ---------- 3) Clipe: fundo + texto + fade + áudio ----------
  const vf = [
    videoChain,
    ...textFilters,
    `fade=t=in:st=0:d=${fade}`,
    `fade=t=out:st=${Math.max(0, duration - fade).toFixed(3)}:d=${fade}`,
    'format=yuv420p[v]',
  ].join(',');
  const af = `[1:a]aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo,apad,afade=t=out:st=${Math.max(0, duration - 0.3).toFixed(3)}:d=0.3[a]`;

  const audioInput = audioFile ? ['-i', audioFile] : ['-f', 'lavfi', '-i', 'anullsrc=r=48000:cl=stereo'];
  const out = `clip_${index}.mp4`;

  await run(config.FFMPEG_PATH, [
    ...BASE_ARGS,
    ...inputArgs, ...audioInput,
    '-filter_complex', `${vf};${af}`,
    '-map', '[v]', '-map', '[a]',
    '-t', duration.toFixed(3), '-r', String(FPS),
    '-c:v', 'libx264', '-preset', config.X264_PRESET, '-crf', String(config.X264_CRF),
    '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-ac', '2',
    out,
  ], { cwd: dir, onProgress, durationSec: duration });

  return path.join(dir, out);
}

/** Junta os clipes (mesmos parâmetros) em um MP4 sem recodificar. */
async function concatClips(dir, clipFiles, outputFile) {
  const list = clipFiles.map((f) => `file '${path.basename(f)}'`).join('\n');
  fs.writeFileSync(path.join(dir, 'list.txt'), list, 'utf8');
  await run(config.FFMPEG_PATH, [
    ...BASE_ARGS, '-f', 'concat', '-safe', '0', '-i', 'list.txt',
    '-c', 'copy', '-movflags', '+faststart', outputFile,
  ], { cwd: dir });
}

// ---------- Música de fundo ----------

/** Acorde como soma de senoides. */
const chord = (freqs) => freqs.map((f) => `sin(2*PI*${f}*t)`).join('+');

/**
 * Trilhas sintéticas (geradas pelo próprio FFmpeg, 100% livres de direitos autorais):
 *  - calm:   pad suave alternando Lá menor ↔ Fá maior, com eco
 *  - upbeat: pad + bumbo e chimbal a 120 BPM
 * Retorna o filtergraph do lavfi (fonte de áudio mono).
 */
function presetSource(name, duration) {
  const d = Math.ceil(duration + 2);
  const Am = chord([110, 220, 261.63, 329.63]);
  const F = chord([87.31, 174.61, 220, 261.63]);
  if (name === 'upbeat') {
    const period = 8;
    const pad = `(0.5+0.5*cos(2*PI*t/${period}))*(${Am})+(0.5-0.5*cos(2*PI*t/${period}))*(${F})`;
    const kick = '0.8*sin(2*PI*(45+110*exp(-35*mod(t,0.5)))*mod(t,0.5))*exp(-9*mod(t,0.5))';
    const hat = '0.25*(random(0)-0.5)*exp(-70*mod(t+0.25,0.5))';
    return `aevalsrc=exprs='0.1*(${pad})+${kick}+${hat}':s=48000:d=${d},lowpass=f=7000,alimiter=limit=0.9`;
  }
  const period = 16;
  const pad = `(0.5+0.5*cos(2*PI*t/${period}))*(${Am})+(0.5-0.5*cos(2*PI*t/${period}))*(${F})`;
  return `aevalsrc=exprs='0.16*(${pad})':s=48000:d=${d},lowpass=f=1500,tremolo=f=0.3:d=0.35,aecho=0.8:0.6:600|900:0.35|0.25,alimiter=limit=0.9`;
}

/**
 * Mixa a música no vídeo final (vídeo é copiado, só o áudio é refeito).
 * @param {object} o
 *   dir, input, output
 *   music      { type:'preset', name } | { type:'file', path }
 *   volume     0..100
 *   duration   duração do vídeo
 *   hasVoice   true = a música abaixa automaticamente quando há narração (sidechain)
 */
async function mixMusic({ dir, input, output, music, volume, duration, hasVoice }) {
  const musicInput = music.type === 'preset'
    ? ['-f', 'lavfi', '-i', presetSource(music.name, duration)]
    : ['-stream_loop', '-1', '-i', music.path];
  const gain = Math.max(0, Math.min(100, volume)) / 100;
  const fadeOutStart = Math.max(0, duration - 1.5).toFixed(3);

  const musicChain = `[1:a]aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo,volume=${gain.toFixed(3)},afade=t=in:st=0:d=1,afade=t=out:st=${fadeOutStart}:d=1.5[m]`;
  const mix = hasVoice
    ? '[0:a]asplit=2[voz][voz2];[m][voz2]sidechaincompress=threshold=0.02:ratio=10:attack=20:release=500[duck];[voz][duck]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[a]'
    : '[0:a][m]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[a]';

  await run(config.FFMPEG_PATH, [
    ...BASE_ARGS, '-i', input, ...musicInput,
    '-filter_complex', `${musicChain};${mix}`,
    '-map', '0:v', '-map', '[a]',
    '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-ar', '48000',
    '-t', duration.toFixed(3), '-movflags', '+faststart', output,
  ], { cwd: dir });
}

module.exports = { checkFfmpeg, probeMedia, probeDuration, renderClip, concatClips, mixMusic };
