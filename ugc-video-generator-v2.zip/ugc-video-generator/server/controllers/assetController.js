'use strict';
/**
 * assetController.js — Upload e gerenciamento da biblioteca de mídias.
 *
 * O upload é "cru" (corpo da requisição = bytes do arquivo), gravado em disco aos poucos
 * (sem estourar a memória) e validado pelos primeiros bytes do arquivo + ffprobe,
 * nunca pelo nome ou pelo Content-Type informado pelo cliente.
 */
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { Transform } = require('stream');
const { pipeline } = require('stream/promises');
const config = require('../config');
const logger = require('../logger');
const assetService = require('../services/assetService');
const ffmpegService = require('../services/ffmpegService');
const { isUuid } = require('./videoController');

const httpError = (status, message) => Object.assign(new Error(message), { status });

/** Identifica o tipo real do arquivo pelos primeiros bytes. */
function sniffType(b) {
  const ascii = (from, to) => b.subarray(from, to).toString('latin1');
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return { kind: 'image', ext: 'jpg', mime: 'image/jpeg' };
  if (b[0] === 0x89 && ascii(1, 4) === 'PNG') return { kind: 'image', ext: 'png', mime: 'image/png' };
  if (ascii(0, 4) === 'RIFF' && ascii(8, 12) === 'WEBP') return { kind: 'image', ext: 'webp', mime: 'image/webp' };
  if (ascii(0, 4) === 'RIFF' && ascii(8, 12) === 'WAVE') return { kind: 'audio', ext: 'wav', mime: 'audio/wav' };
  if (ascii(4, 8) === 'ftyp') {
    const brand = ascii(8, 12);
    if (/^(heic|heix|hevc|hevx|mif1|msf1|avif)/.test(brand)) return null; // HEIC/AVIF: FFmpeg comum não decodifica
    if (brand === 'M4A ') return { kind: 'audio', ext: 'm4a', mime: 'audio/mp4' };
    if (brand === 'qt  ') return { kind: 'video', ext: 'mov', mime: 'video/quicktime' };
    return { kind: 'video', ext: 'mp4', mime: 'video/mp4' };
  }
  if (b[0] === 0x1a && b[1] === 0x45 && b[2] === 0xdf && b[3] === 0xa3) return { kind: 'video', ext: 'webm', mime: 'video/webm' };
  if (ascii(0, 3) === 'ID3' || (b[0] === 0xff && (b[1] & 0xe0) === 0xe0)) return { kind: 'audio', ext: 'mp3', mime: 'audio/mpeg' };
  if (ascii(0, 4) === 'OggS') return { kind: 'audio', ext: 'ogg', mime: 'audio/ogg' };
  if (ascii(0, 4) === 'fLaC') return { kind: 'audio', ext: 'flac', mime: 'audio/flac' };
  return null;
}

/** Nome original seguro para exibição. */
function cleanName(raw) {
  let name = String(raw || 'arquivo');
  try { name = decodeURIComponent(name); } catch (_) { /* mantém */ }
  return path.basename(name).replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, 120) || 'arquivo';
}

/** Grava o corpo da requisição em disco, abortando se passar do limite. */
async function receiveToFile(req, destination, maxBytes) {
  let received = 0;
  const counter = new Transform({
    transform(chunk, _enc, cb) {
      received += chunk.length;
      if (received > maxBytes) return cb(httpError(413, `Arquivo grande demais (máximo ${Math.round(maxBytes / 1048576)} MB).`));
      cb(null, chunk);
    },
  });
  await pipeline(req, counter, fs.createWriteStream(destination));
  return received;
}

/** POST /api/assets/upload  — corpo = arquivo; cabeçalho X-Filename = nome original (URL-encoded) */
exports.upload = async (req, res, next) => {
  const tmp = path.join(config.TMP_DIR, `upload-${crypto.randomUUID()}`);
  let finalPath = null;
  try {
    const biggest = Math.max(...Object.values(config.MAX_UPLOAD_BYTES));
    const declared = parseInt(req.headers['content-length'], 10);
    if (declared > biggest) throw httpError(413, 'Arquivo grande demais.');

    const size = await receiveToFile(req, tmp, biggest);
    if (size < 16) throw httpError(400, 'Arquivo vazio ou inválido.');

    const fd = fs.openSync(tmp, 'r');
    const head = Buffer.alloc(16);
    fs.readSync(fd, head, 0, 16, 0);
    fs.closeSync(fd);

    const type = sniffType(head);
    if (!type) throw httpError(415, 'Formato não suportado. Use JPG, PNG, WebP, MP4, MOV, WebM, MP3, WAV, M4A, OGG ou FLAC.');
    if (size > config.MAX_UPLOAD_BYTES[type.kind]) {
      throw httpError(413, `${type.kind === 'image' ? 'Imagem' : type.kind === 'video' ? 'Vídeo' : 'Áudio'} grande demais (máximo ${Math.round(config.MAX_UPLOAD_BYTES[type.kind] / 1048576)} MB).`);
    }

    // ffprobe confirma que o arquivo realmente é uma mídia legível
    let info;
    try { info = await ffmpegService.probeMedia(tmp); } catch (_) { throw httpError(415, 'Não foi possível ler esse arquivo de mídia (corrompido?).'); }
    if ((type.kind === 'image' || type.kind === 'video') && !info.hasVideo) throw httpError(415, 'Arquivo sem imagem/vídeo válido.');
    if (type.kind === 'audio' && !info.hasAudio) throw httpError(415, 'Arquivo sem áudio válido.');
    if (type.kind !== 'image' && !(info.duration > 0)) throw httpError(415, 'Não foi possível determinar a duração da mídia.');

    const id = crypto.randomUUID();
    finalPath = path.join(config.UPLOADS_DIR, `${id}.${type.ext}`);
    fs.renameSync(tmp, finalPath);

    const asset = assetService.createAsset({
      kind: type.kind, originalName: cleanName(req.headers['x-filename']), filePath: finalPath, mime: type.mime, size,
      width: info.width, height: info.height, durationSec: type.kind === 'image' ? null : info.duration,
    }, id);
    logger.info(`Mídia ${id} enviada (${type.kind}, ${(size / 1048576).toFixed(1)} MB)`);
    res.status(201).json({ asset });
  } catch (err) {
    fs.rm(tmp, { force: true }, () => {});
    if (finalPath) fs.rm(finalPath, { force: true }, () => {});
    // Requisição abortada pelo cliente ou estourou o limite: responde sem derrubar o servidor
    if (err.code === 'ERR_STREAM_PREMATURE_CLOSE') return;
    next(err);
  }
};

/** GET /api/assets?kind=image|video|audio */
exports.list = (req, res) => {
  const kind = ['image', 'video', 'audio'].includes(req.query.kind) ? req.query.kind : undefined;
  res.json({ assets: assetService.listAssets(kind) });
};

/** GET /api/assets/:id/file  (suporta Range para pré-visualizar vídeos/áudios) */
exports.file = (req, res) => {
  if (!isUuid(req.params.id)) return res.status(400).json({ error: 'ID inválido.' });
  const row = assetService.getAssetRow(req.params.id);
  if (!row || !fs.existsSync(row.file_path)) return res.status(404).json({ error: 'Mídia não encontrada.' });
  res.type(row.mime).sendFile(row.file_path);
};

/** DELETE /api/assets/:id */
exports.remove = (req, res) => {
  if (!isUuid(req.params.id)) return res.status(400).json({ error: 'ID inválido.' });
  if (!assetService.getAssetRow(req.params.id)) return res.status(404).json({ error: 'Mídia não encontrada.' });
  if (assetService.isAssetInUse(req.params.id)) return res.status(409).json({ error: 'Esta mídia está sendo usada por um vídeo na fila ou em processamento. Tente novamente quando ele terminar.' });
  assetService.deleteAsset(req.params.id);
  res.json({ ok: true });
};
