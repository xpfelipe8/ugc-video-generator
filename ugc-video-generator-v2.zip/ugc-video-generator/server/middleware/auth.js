'use strict';
/**
 * middleware/auth.js — Login simples (cookie assinado) + API key.
 *
 * - Desativado por padrão: só liga se AUTH_PASSWORD ou API_KEY estiverem no .env.
 * - Painel web: POST /api/auth/login cria um cookie HttpOnly assinado com HMAC-SHA256.
 * - Automação (curl, n8n, Zapier...): envie o cabeçalho  X-API-Key: <API_KEY>
 *   (ou Authorization: Bearer <API_KEY>).
 */
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const config = require('../config');

const COOKIE_NAME = 'ugc_session';
const enabled = Boolean(config.AUTH_PASSWORD || config.API_KEY);

/** Segredo de assinatura: vem do .env ou é gerado uma vez e guardado em data/.session_secret */
function loadSecret() {
  if (config.SESSION_SECRET) return config.SESSION_SECRET;
  const file = path.join(config.DATA_DIR, '.session_secret');
  try {
    const existing = fs.readFileSync(file, 'utf8').trim();
    if (existing) return existing;
  } catch (_) { /* ainda não existe */ }
  const secret = crypto.randomBytes(32).toString('hex');
  fs.writeFileSync(file, secret, { mode: 0o600 });
  return secret;
}
const SECRET = loadSecret();

const sha256 = (v) => crypto.createHash('sha256').update(String(v)).digest();
/** Comparação em tempo constante (evita ataque de timing). */
const safeEqual = (a, b) => crypto.timingSafeEqual(sha256(a), sha256(b));
const sign = (payload) => crypto.createHmac('sha256', SECRET).update(payload).digest('base64url');

function createToken(user) {
  const payload = Buffer.from(JSON.stringify({ u: user, exp: Date.now() + config.SESSION_TTL_MS })).toString('base64url');
  return `${payload}.${sign(payload)}`;
}

function verifyToken(token) {
  if (typeof token !== 'string' || !token.includes('.')) return null;
  const [payload, signature] = token.split('.');
  const expected = sign(payload);
  if (signature.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) return null;
  try {
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    return data.exp > Date.now() ? data.u : null;
  } catch (_) { return null; }
}

function parseCookies(header = '') {
  const out = {};
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

/** Retorna o nome do usuário autenticado (ou 'api') / null. Se auth está desligada, sempre autentica. */
function authenticate(req) {
  if (!enabled) return config.AUTH_USER;
  if (config.API_KEY) {
    const bearer = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const key = req.headers['x-api-key'] || bearer;
    if (key && safeEqual(key, config.API_KEY)) return 'api';
  }
  return verifyToken(parseCookies(req.headers.cookie)[COOKIE_NAME]);
}

function requireAuth(req, res, next) {
  if (authenticate(req)) return next();
  res.status(401).json({ error: 'Não autenticado.' });
}

function setSessionCookie(res, user) {
  const flags = ['HttpOnly', 'SameSite=Lax', 'Path=/', `Max-Age=${Math.floor(config.SESSION_TTL_MS / 1000)}`];
  if (config.COOKIE_SECURE) flags.push('Secure');
  res.setHeader('Set-Cookie', `${COOKIE_NAME}=${createToken(user)}; ${flags.join('; ')}`);
}

function clearSessionCookie(res) {
  res.setHeader('Set-Cookie', `${COOKIE_NAME}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0`);
}

module.exports = { enabled, authenticate, requireAuth, setSessionCookie, clearSessionCookie, safeEqual };
